#! /bin/bash
rsync -avh /main/dummy root@172.22.0.3:/main/