#!bin/bash

rm -r /main/
rm -r /backup/
